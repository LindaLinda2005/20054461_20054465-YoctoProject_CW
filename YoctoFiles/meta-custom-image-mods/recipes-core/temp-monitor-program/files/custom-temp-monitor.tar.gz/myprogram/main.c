#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <modbus/modbus.h>
#include <unistd.h>
#include <string.h>

#define SERVER_IP "192.168.137.100"  // Server IP
#define SERVER_PORT 1502         // Modbus TCP port
#define REGISTER_ADDRESS 0       // Modbus register address to write/read


// Modbus server config - old, not working
/*void run_server() {
    printf("Starting server...\n");

    modbus_t *ctx = modbus_new_tcp(NULL, SERVER_PORT);
    modbus_set_debug(ctx, TRUE);
    modbus_set_slave(ctx, 0);

    if (ctx == NULL) {
        fprintf(stderr, "Error: Unable to create Modbus context\n");
        exit(EXIT_FAILURE);
    } else {
        printf("Modbus context successfully created\n");
    }

    modbus_mapping_t *mb_mapping = modbus_mapping_new(0, 0, 1, 0);
    if (mb_mapping == NULL) {
        fprintf(stderr, "Error: Unable to allocate Modbus mapping\n");
        modbus_free(ctx);
        exit(EXIT_FAILURE);
    } else {
        printf("Modbus mapping successfully allocated\n");
    }

    int socket = modbus_tcp_listen(ctx, 1); //new
    if (socket == -1) {
        fprintf(stderr, "Error: modbus_tcp_listen failed\n");
        modbus_mapping_free(mb_mapping);
        modbus_free(ctx);
        exit(EXIT_FAILURE);
    } else {
        printf("Server is listening on port %d\n", SERVER_PORT);
    }

    printf("Allocating register addresses to 0\n");
    mb_mapping->tab_registers[0] = 0; // Initialize holding register at address 0

    printf("Server Running...\n");

while (1) {
    // Accept client connection
    printf("Waiting for a client connection...\n");
    if (modbus_tcp_accept(ctx, &socket) == -1) {
        fprintf(stderr, "Error: modbus_tcp_accept failed\n");
        continue; // Exit the loop on failure
    } else {
        printf("Client connected\n");
    }

    // Accept and handle connections
    while (1) {
        int rc;
        uint8_t query[MODBUS_TCP_MAX_ADU_LENGTH];

        // Receive Modbus query from client
        rc = modbus_receive(ctx, query);
        if (rc > 0) {
            printf("Received valid Modbus request (length: %d)\n", rc);
            printf("Current Value in the Holding Register[0]: %d\n", mb_mapping->tab_registers[0]);
            printf("First byte of query: %d\n", query[0]);
            printf("ctx pointer value: %p\n\n", ctx);

            // Process and reply to the client
            if (modbus_reply(ctx, query, rc, mb_mapping) == -1) {
                fprintf(stderr, "Error: modbus_reply failed\n");
                break; // Exit the loop on failure
            } else {
                printf("Response sent. Updated Value in the Holding Register[0]: %d\n", mb_mapping->tab_registers[0]);
            }
        } else if (rc == -1) {
            fprintf(stderr, "Error: modbus_receive failed, closing connection\n");
            break; // Exit the loop on failure
        }
    }

    printf("Closing client connection...\n");
    close(socket); // Clean up the client socket

}
    // Cleanup resources
    printf("Shutting down server...\n");
    modbus_mapping_free(mb_mapping);
    modbus_free(ctx);
    printf("Server shutdown complete\n");
}
*/

int get_cpu_temp() {
    FILE *fp;
    int cpu_temp;
    char buffer[16];

    // open the file storing temperature data
    fp = fopen("cat /sys/class/thermal/thermal_zone0/temp", "r");
    //fp = popen("cat /sys/class/thermal/thermal_zone0/temp", "r");
    if (fp == NULL) {
        perror("Failed to run command\n");
        return -1; // Return error code
    }

    if (fgets(buffer, sizeof(buffer), fp) != NULL) {
        cpu_temp = atoi(buffer);
    } else {
        perror("Failed to read CPU temp\n");
        pclose(fp);
        return -1;
    }

    // Close the file
    pclose(fp);

    return cpu_temp;
}

// Modbus server config
void run_server() {
    printf("Starting server...\n");

    // Create Modbus context
    modbus_t *ctx = modbus_new_tcp(NULL, SERVER_PORT);
    if (ctx == NULL) {
        fprintf(stderr, "Error: Unable to create Modbus context\n");
        exit(EXIT_FAILURE);
    }

    //Debug only
    //modbus_set_debug(ctx, TRUE);
    //modbus_set_slave(ctx, 0); // Set default slave ID

    // Allocate Modbus mapping
    modbus_mapping_t *mb_mapping = modbus_mapping_new(0, 0, 2, 0); // 1 holding register
    if (mb_mapping == NULL) {
        fprintf(stderr, "Error: Unable to allocate Modbus mapping\n");
        modbus_free(ctx);
        exit(EXIT_FAILURE);
    }
    mb_mapping->tab_registers[0] = 0; // Initialize holding register
    mb_mapping->tab_registers[1] = 0;

    // Start listening for connections
    int server_socket = modbus_tcp_listen(ctx, 1); // Backlog of 1 connection
    if (server_socket == -1) {
        fprintf(stderr, "Error: modbus_tcp_listen failed\n");
        modbus_mapping_free(mb_mapping);
        modbus_free(ctx);
        exit(EXIT_FAILURE);
    }
    printf("Server is listening on port %d\n", SERVER_PORT);

    while (1) {
        printf("Waiting for a client connection...\n");

        // Accept a client connection
        int client_socket = modbus_tcp_accept(ctx, &server_socket);
        if (client_socket == -1) {
            fprintf(stderr, "Error: modbus_tcp_accept failed: %s\n", modbus_strerror(errno));
            continue; // Retry accepting new connections
        }
        printf("Client connected\n\n");

        // Handle client requests
        while (1) {
            uint8_t query[MODBUS_TCP_MAX_ADU_LENGTH];
            int rc = modbus_receive(ctx, query);
            uint8_t function_code = query[7];

            if (rc > 0) {

                // Shift CPU temp into holding register
                mb_mapping->tab_registers[1] = get_cpu_temp();

                switch (function_code) {
                    case 0x03:
                        printf("Received Modbus Read Holding Registers request (length: %d)\n", rc);
                    break;
                    case 0x06:
                        printf("Received Modbus Write Single Register request (length: %d)\n", rc);
                    break;
                    case 0x10:
                        printf("Received Modbus Write Multiple Registers request (length: %d)\n", rc);
                    break;
                    default:
                        printf("Received unknown Modbus request (function code: 0x%02X, length: %d)\n", function_code, rc);
                    break;
                }

                printf("Current Value in the Holding Register[0]: %d\n", mb_mapping->tab_registers[0]);

                // Send response to the client
                if (modbus_reply(ctx, query, rc, mb_mapping) == -1) {
                    fprintf(stderr, "Error: modbus_reply failed: %s\n", modbus_strerror(errno));
                    break; // Exit client loop on failure
                }
                printf("Response sent.\nCurrent Value in the Holding Register[0]: %d\n\n", mb_mapping->tab_registers[0]);
            } else if (rc == -1) {
                if (errno == ECONNRESET) {
                    // Suppress redundant "Connection reset by peer" errors in application logs
                    printf("Client disconnected gracefully\n");
                } else {
                    // Log unexpected errors
                    fprintf(stderr, "Error: modbus_receive failed (errno: %d): %s\n", errno, modbus_strerror(errno));
                }
                break;
            }
        }
        printf("Closing client connection...\n");
        close(client_socket); // Clean up the client socket
    }

    // Cleanup resources (this will never be reached in an infinite loop)
    printf("Shutting down server...\n");
    close(server_socket);
    modbus_mapping_free(mb_mapping);
    modbus_free(ctx);
    printf("Server shutdown complete\n");
}

// Modbus client config
void run_client() {
    modbus_t *ctx = modbus_new_tcp(SERVER_IP, SERVER_PORT);

    //Debug only
    //modbus_set_debug(ctx, TRUE);
    //modbus_set_slave(ctx, 0);
    //modbus_set_response_timeout(ctx, 5, 0);  // 5 seconds timeout


    if (ctx == NULL) {
        fprintf(stderr, "Unable to create Modbus context\n");
        exit(EXIT_FAILURE);
    }

    if (modbus_connect(ctx) == -1) {
        fprintf(stderr, "Connection failed\n");
        modbus_free(ctx);
        exit(EXIT_FAILURE);
    }

    printf("Connected to server\n");

    // Write a value to the server
    uint16_t value = 42;
    if (modbus_write_register(ctx, REGISTER_ADDRESS, value) == -1) {
        fprintf(stderr, "Failed to write register\n");
    } else {
        printf("Wrote value %d to server\n", value);
    }

    // Read a value from the server
    uint16_t read_value[2];
    if (modbus_read_registers(ctx, 0, 2, read_value) == -1) {
        fprintf(stderr, "Failed to read register: %s\n", modbus_strerror(errno));
    } else {
        printf("Read values[0]: %d, value[1]: %d from server\n", read_value[0], read_value[1]);
    }

    modbus_close(ctx);
    modbus_free(ctx);

}

// Main
int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s [server|client]\n", argv[0]);
        return EXIT_FAILURE;
    }

    if (strcmp(argv[1], "server") == 0) {
        run_server();
    } else if (strcmp(argv[1], "client") == 0) {
        run_client();
    } else {
        fprintf(stderr, "Invalid mode. Use 'server' or 'client'.\n");
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}
