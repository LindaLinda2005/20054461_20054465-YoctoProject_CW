#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <modbus/modbus.h>
#include <unistd.h>
#include <string.h>

#define SERVER_IP "192.168.137.100"  // Server IP
#define SERVER_PORT 1502         // Modbus TCP port
#define REGISTER_ADDRESS 0       // Modbus register address to write/read

// global variables
int cpu_state = 0;

// Function to read CPU temp
int get_cpu_temp() {
    // DEBUG
    printf("calling 'get_cpu_temp'\n");

    // Defining variables
    FILE *fp;
    int cpu_temp;
    char buffer[16];

    // Open file storing temperature data
    fp = popen("cat /sys/class/thermal/thermal_zone0/temp", "r");
    if (fp == NULL) {
        perror("Failed to run command\n");
        return -1; // Return error code
    }

    // If loop stores value of buffer into int
    if (fgets(buffer, sizeof(buffer), fp) != NULL) {
        cpu_temp = atoi(buffer);
    } else {
        perror("Failed to read CPU temp\n");
        pclose(fp);
        return -1;
    }

    // Close the file
    pclose(fp);
    return cpu_temp;
}

// Function to monitor CPU_temp
int monitor_cpu_temp(uint16_t cpu_temp[1], int *time_cpu) {
    // DEBUG
    printf("calling 'monitor_cpu_temp'\n");

    // if cpu temp is high it will increase a timer
    if (cpu_temp[0] > 3600) {
        // DEBUG
        printf("DEBUG: CPU temp too high, time_cpu: %d\n", *time_cpu);
        if (*time_cpu >= 10) {
            *time_cpu = 10;
        } else {
            (*time_cpu)++;
        }
    } else if (cpu_temp[0] < 60 && *time_cpu > 0) {
        *time_cpu--;
    }

    // DEBUG
    printf("DEBUG: time_cpu: %d\n", *time_cpu);

    // Checks if cpu temp has been too high for too long
    if (*time_cpu > 3) {
        cpu_state = 0;
    } else {
        cpu_state = 1;
    }
    return cpu_state;
}

// Modbus server config
void run_server() {
    int STOP_PROGRAM = 0;
    int START_PROGRAM = 0;
    int numberOfConnections = 0;

    // Print to console
    printf("Starting server...\n");

    // Create Modbus context
    modbus_t *ctx = modbus_new_tcp(NULL, SERVER_PORT);
    if (ctx == NULL) {
        fprintf(stderr, "Error: Unable to create Modbus context\n");
        exit(EXIT_FAILURE);
    }

    //Debug only
    //modbus_set_debug(ctx, TRUE);

    // Allocate Modbus mapping
    modbus_mapping_t *mb_mapping = modbus_mapping_new(0, 0, 2, 0); // 1 holding register
    if (mb_mapping == NULL) {
        fprintf(stderr, "Error: Unable to allocate Modbus mapping\n");
        modbus_free(ctx);
        exit(EXIT_FAILURE);
    }

    mb_mapping->tab_registers[0] = 0; // Initialize holding register (CPU_TEMP)
    mb_mapping->tab_registers[1] = 0; // Initialize holding register (START=1, STOP=0)

    // Start listening for connections
    int server_socket = modbus_tcp_listen(ctx, 1); // Backlog of 1 connection
    if (server_socket == -1) {
        fprintf(stderr, "Error: modbus_tcp_listen failed\n");
        modbus_mapping_free(mb_mapping);
        modbus_free(ctx);
        exit(EXIT_FAILURE);
    }

    // Print to console
    printf("Server is listening on port %d\n", SERVER_PORT);

    // Forever while loop
    while (1) {
        // Print to console
        printf("Waiting for a client connection...\n");

        // Accept a client connection
        int client_socket = modbus_tcp_accept(ctx, &server_socket);
        if (client_socket == -1) {
            fprintf(stderr, "Error: modbus_tcp_accept failed: %s\n", modbus_strerror(errno));
            continue; // Retry accepting new connections
        }

        if (numberOfConnections > 10000) {
            printf("Number of connections has exceeded maximum allowable\n\n");
            exit(EXIT_FAILURE);
        } else {
            printf("Client connected\n\n");
            numberOfConnections++;
            printf("Number of connections: %d\n", numberOfConnections);
        }

        // Defining Variables
        uint8_t query[MODBUS_TCP_MAX_ADU_LENGTH];
        int rc = modbus_receive(ctx, query);
        uint8_t function_code = query[7];

        // Handle client requests
        while (1) {

            if (rc > 0) {
                // Switch case dependent on request type
                switch (function_code) {
                    case 0x03:
                        printf("Received Modbus Read Holding Registers request (length: %d)\n", rc);
                    mb_mapping->tab_registers[0] = get_cpu_temp();
                    break;
                    case 0x06:
                        printf("Received Modbus Write Single Register request (length: %d)\n", rc);
                    break;
                    case 0x10:
                        printf("Received Modbus Write Multiple Registers request (length: %d)\n", rc);
                    break;
                    default:
                        printf("Received unknown Modbus request (function code: 0x%02X, length: %d)\n", function_code, rc);
                    break;
                }

                // Send response to the client
                if (modbus_reply(ctx, query, rc, mb_mapping) == -1) {
                    fprintf(stderr, "Error: modbus_reply failed: %s\n", modbus_strerror(errno));
                    break; // Exit client loop on failure
                }

                // CW
                if (function_code == 0x03) {
                    printf("Read request processed.\nUpdated Value in the cpu temp Register[0]: %d\n", mb_mapping->tab_registers[0]);
                }

                // If a write request has been processed
                if (function_code == 0x06) {
                    printf("Write request processed.\nUpdated Value in the start/stop Register[1]: %d\n", mb_mapping->tab_registers[1]);

                    // If stop request received
                    if (mb_mapping->tab_registers[1] != 1) {
                        // STOP_PROGRAM - HOW?? (fails safe)
                        STOP_PROGRAM = 1;
                        START_PROGRAM = 0;
                        printf("Stop request received. Stopping process...\n\n");
                    } else {
                        // START_PROGRAM - HOW??
                        STOP_PROGRAM = 0;
                        START_PROGRAM = 1;
                        printf("Start request received. Starting process...\n\n");
                    }
                }
            }

            // Error handling
            else if (rc == -1) {
                if (errno == ECONNRESET) {
                    // Suppress redundant "Connection reset by peer" errors in application logs
                    printf("Client disconnected gracefully\n");
                } else {
                    // Log unexpected errors
                    fprintf(stderr, "Error: modbus_receive failed (errno: %d): %s\n", errno, modbus_strerror(errno));
                }
                break;
            }

            printf("End of client request");
            break;
        }
    }

    // Cleanup resources (this will never be reached in an infinite loop)
    printf("Shutting down server...\n");
    close(server_socket);
    modbus_mapping_free(mb_mapping);
    modbus_free(ctx);
    printf("Server shutdown complete\n");
}

// Modbus client config
void run_client(int log_rate) {
    // DEBUG
    printf("starting client\n");

    int tempTest = 0;
    int clockTime = log_rate - 1;
    int start_req = 0, stop_req = 0;
    int valueOfTime_cpu = 0;
    int *time_cpu = &valueOfTime_cpu;
    uint16_t read_value[1];

    modbus_t *ctx = modbus_new_tcp(SERVER_IP, SERVER_PORT);

    //Debug only
    //modbus_set_debug(ctx, TRUE);
    //modbus_set_slave(ctx, 0);
    //modbus_set_response_timeout(ctx, 5, 0);  // 5 seconds timeout

    if (ctx == NULL) {
        fprintf(stderr, "Unable to create Modbus context\n");
        exit(EXIT_FAILURE);
    }

    if (modbus_connect(ctx) == -1) {
        fprintf(stderr, "Connection failed\n");
        modbus_free(ctx);
        exit(EXIT_FAILURE);
    }

    printf("Connected to server\n");

    while (1) {
        // DEBUG
        printf("starting 3s delay\n");
        sleep(3);
        clockTime++;
        // DEBUG
        printf("end 3s delay client\n");

        // Read cpu temp at a set time interval
        if (clockTime == log_rate) {

            // DEBUG
            printf("clock has reached log rate\n");

            // Read a value from the server
            if (modbus_read_registers(ctx, 0, 1, read_value) == -1) {
                fprintf(stderr, "Failed to read register: %s\n", modbus_strerror(errno));
            } else {
                printf("Current CPU temperature of server: [%hu]\n", read_value[0]);
            }

            tempTest = monitor_cpu_temp(read_value, time_cpu);


            // Call function to assess CPU temp
            if (tempTest == 0) {
                // Request a write request to stop the process
                stop_req = 1;
                start_req = 0;
            } else {
                stop_req = 0;
                start_req = 1;
            }
        }

        // DEBUG
        printf("DEBUG: closed connection. Assess if process requires stop.\n");

        // If a start request is received
        if (start_req == 1 && stop_req == 0) {
            // Write a value to the server
            if (modbus_write_register(ctx, REGISTER_ADDRESS, start_req) == -1) {
                fprintf(stderr, "Failed to write register\n");
            } else {
                printf("Wrote value %d to server\n", start_req);
            }
            // reset flag
            start_req = 0;
        }

        // If a stop request is received
        else if (start_req == 0 && stop_req == 1) {
            // Write a value to the server
            if (modbus_write_register(ctx, REGISTER_ADDRESS, stop_req) == -1) {
                fprintf(stderr, "Failed to write register\n");
            } else {
                printf("Wrote value %d to server\n", stop_req);
            }
            // reset flag
            stop_req = 0;
        }
    }

    // Close Modbus connection
    modbus_close(ctx);
    modbus_free(ctx);
    clockTime = 0;
}

// Main
int main(int argc, char *argv[]) {
    if (strcmp(argv[1], "server") == 0) {
        if (argc != 2) {
            fprintf(stderr, "Usage: %s [server|client]\n", argv[0]);
            return EXIT_FAILURE;
        }
        run_server();
    }

    if (strcmp(argv[1], "client") == 0) {
        if (argc != 3) {
            fprintf(stderr, "Usage: %s [server|client] [logging_rate (seconds)]\n", argv[0]);
            return EXIT_FAILURE;
        }

        // Parse logging rate from the second argument
        int logging_rate = atoi(argv[2]);
        if (logging_rate <= 0) {
            fprintf(stderr, "Invalid logging_rate\n");
            return EXIT_FAILURE;
        }
        if (logging_rate < 5) {
            printf("Logging_rate must be greater than 5s\n...forced to 5s\n");
            logging_rate = 5;
        }
        if (logging_rate > 60) {
            printf("Logging_rate maximum is 60s\n...forced to 60s\n");
            logging_rate = 60;
        }

        run_client(logging_rate);
    } else {
        fprintf(stderr, "Invalid mode. Use 'server' or 'client'.\n");
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}